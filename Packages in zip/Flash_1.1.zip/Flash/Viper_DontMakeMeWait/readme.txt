*** How to install ***

Unpack the Viper_DontMakeMeWait directory into \Data\Gui\Customized\Flash\ located in the root of your The Secret World directory, so it looks like this:

\Data\Gui\Customized\Flash\Viper_DontMakeMeWait\CharPrefs.xml
\Data\Gui\Customized\Flash\Viper_DontMakeMeWait\LoginPrefs.xml


PLEASE NOTE: Make sure you restart your client after installing this add-on. Always restart your client when adding XML files as these only get read on load.



*** How to uninstall ***

Simply delete the Viper_DontMakeMeWait directory from \Data\Gui\Customized\Flash\.



/Viper

- My blog for following my add-on development: http://tswaddons.wordpress.com/
