*** How to install ***

Unpack the Viper_CastbarRelocator directory and DodgeBar.swf, PlayerCastBar.swf and TargetCastBar.swf into \Data\Gui\Customized\Flash\ located in the root of your The Secret World directory, so it looks like this:

\Data\Gui\Customized\Flash\Viper_CastbarRelocator\Viper_CastbarRelocator.swf
\Data\Gui\Customized\Flash\Viper_CastbarRelocator\LoginPrefs.xml
\Data\Gui\Customized\Flash\Viper_CastbarRelocator\Modules.xml
\Data\Gui\Customized\Flash\DodgeBar.swf
\Data\Gui\Customized\Flash\PlayerCastBar.swf
\Data\Gui\Customized\Flash\TargetCastBar.swf


If you want to be able to open the window using the /vcr slash command copy the Scripts directory into the root of your The Secret World directory.
Should look something like this then: \The Secret World\Scripts\vcr



*** How to uninstall ***

Delete the Viper_CastbarRelocator directory and DodgeBar.swf, PlayerCastBar.swf and TargetCastBar.swf from \Data\Gui\Customized\Flash\.



/Viper

- Follow my add-on development: http://tswaddons.wordpress.com/