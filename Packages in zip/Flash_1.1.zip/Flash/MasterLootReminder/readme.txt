v1.0a features:
* Entering one of the three raid zones as a Raid Leader will trigger a prompt asking if you'd like to enable Master Looter.
* Zones monitored: "Manhattan Exclusion Zone", "N'Gha-Pei the Corpse-Island", "Agartha Defiled"

Installation:
Unpack the .zip archive into <your Secret World Directory>\Data\Gui\Customized\Flash\ folder, overwrite if files already exists.
If The Secret World is running when you install this addon, you must completely close the game client and restart before the addon will take effect.

Included files:
\Data\Gui\Customized\Flash\MasterLootReminder\CharPrefs.xml
\Data\Gui\Customized\Flash\MasterLootReminder\Modules.xml
\Data\Gui\Customized\Flash\MasterLootReminder\MasterLootReminder.swf
\Data\Gui\Customized\Flash\MasterLootReminder\readme.txt

Uninstallation:
Delete the \Data\Gui\Customized\Flash\MasterLootReminder folder

Acknowledgements:
This mod is the spiritual successor of RAIDR by Valyrie